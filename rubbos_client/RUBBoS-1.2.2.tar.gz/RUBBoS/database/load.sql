load data infile "/home/cecchet/RUBBoS/database/users.data" into table users fields terminated by "\t";
load data infile "/home/cecchet/RUBBoS/database/stories.data" into table stories fields terminated by "\t";
load data infile "/home/cecchet/RUBBoS/database/comments.data" into table comments fields terminated by "\t";
load data infile "/home/cecchet/RUBBoS/database/old_stories.data" into table old_stories fields terminated by "\t";
load data infile "/home/cecchet/RUBBoS/database/old_comments.data" into table old_comments fields terminated by "\t";
load data infile "/home/cecchet/RUBBoS/database/submissions.data" into table submissions fields terminated by "\t";
load data infile "/home/cecchet/RUBBoS/database/moderator_log.data" into table moderator_log fields terminated by "\t";

