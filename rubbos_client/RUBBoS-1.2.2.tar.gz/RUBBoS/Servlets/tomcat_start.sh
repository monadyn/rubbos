#!/bin/sh

CLASSPATH=/usr/local/mysql/mm.mysql-2.0.14-bin.jar
export CLASSPATH

#/opt/jakarta-tomcat-3.2.3/bin/startup.sh
/opt/jakarta-tomcat-4.1.24/bin/startup.sh