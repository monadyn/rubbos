#!/bin/bash

\cp Config.java ../Config.java
\cp RubbosHttpServlet.java ../RubbosHttpServlet.java
\cp ViewComment.java ../ViewComment.java 
\cp ViewStory.java ../ViewStory.java
