#!/bin/bash

\cp Config.java_twoGlobalConnPool ../Config.java
\cp RubbosHttpServlet.java_twoGlobalConnPool ../RubbosHttpServlet.java
\cp ViewComment.java_twoGlobalConnPool ../ViewComment.java 
\cp ViewStory.java_twoGlobalConnPool ../ViewStory.java
