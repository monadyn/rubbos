#!/bin/bash

\cp Config.java_original ../Config.java
\cp RubbosHttpServlet.java_original ../RubbosHttpServlet.java
\cp ViewComment.java_original ../ViewComment.java 
\cp ViewStory.java_original ../ViewStory.java
