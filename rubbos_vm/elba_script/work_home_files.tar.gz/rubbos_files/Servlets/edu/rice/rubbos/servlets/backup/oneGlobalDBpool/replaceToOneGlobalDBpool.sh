#!/bin/bash

\cp Config.java_globalConnPool ../Config.java
\cp RubbosHttpServlet.java_globalConnPool ../RubbosHttpServlet.java
\cp ViewComment.java_globalConnPool ../ViewComment.java 
\cp ViewStory.java_globalConnPool ../ViewStory.java
