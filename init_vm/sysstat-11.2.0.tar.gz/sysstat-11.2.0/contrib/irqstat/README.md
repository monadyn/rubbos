irqstat
=======

A better way to watch /proc/interrupts, designed for NUMA systems with many processors.

Contributed by Lance Shelton <lance.shelton@sandisk.com>

